import pandas as pd
import random

# List of 15 different IP addresses

# Read the large CSV file
df = pd.read_csv('Train_data.csv')

# Add the ne\\\
print(df)